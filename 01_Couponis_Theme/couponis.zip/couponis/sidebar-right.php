<?php
if ( is_active_sidebar( 'right' ) ){
	dynamic_sidebar( 'right' );
}
?>