<?php
if ( is_active_sidebar( 'coupon' ) ){
	dynamic_sidebar( 'coupon' );
}
?>